import io
import json
import re
import os
from datetime import timedelta

import azure.functions as func
from azure.identity import DefaultAzureCredential
from azure.monitor.query import LogsQueryClient
from openpyxl import Workbook

# Regex to sanitize sheet names (Excel restrictions)
SHEET_SANITIZE = re.compile(r'[:\\/?*\[\]]')

def sanitize_sheet_name(name: str) -> str:
    clean = SHEET_SANITIZE.sub("-", name or "Sheet")
    return clean[:31] if clean else "Sheet"

def kql_query(days: int) -> str:
    return f"""
let cpu = Perf
| where TimeGenerated >= ago({days}d)
| where ObjectName == "Processor" and CounterName == "% Processor Time" and InstanceName == "_Total"
| summarize AvgCPU=round(avg(CounterValue),2), MaxCPU=round(max(CounterValue),2), P95CPU=round(percentile(CounterValue,95),2) by Computer;
let mem = Perf
| where TimeGenerated >= ago({days}d)
| where ObjectName == "Memory" and CounterName in ("% Committed Bytes In Use", "% Used Memory")
| summarize AvgMem=round(avg(CounterValue),2), MaxMem=round(max(CounterValue),2), P95Mem=round(percentile(CounterValue,95),2) by Computer;
cpu
| join kind=fullouter mem on Computer
| project Computer, AvgCPU, MaxCPU, P95CPU, AvgMem, MaxMem, P95Mem
| order by Computer asc
"""

def run_query(client: LogsQueryClient, workspace_id: str, query: str):
    result = client.query_workspace(workspace_id, query, timespan=timedelta(days=1))
    tables = result.tables
    if not tables:
        return [], []
    table = tables[0]
    headers = [c.name for c in table.columns]
    rows = [[cell for cell in row] for row in table.rows]
    return headers, rows

def to_excel(sheets_data):
    wb = Workbook()
    wb.remove(wb.active)  # remove default sheet
    for sheet_name, headers, rows in sheets_data:
        ws = wb.create_sheet(title=sanitize_sheet_name(sheet_name))
        if headers:
            ws.append(headers)
            for r in rows:
                ws.append(r)
        else:
            ws.append(["Info"])
            ws.append(["No data returned for this workspace/time window"])
    stream = io.BytesIO()
    wb.save(stream)
    stream.seek(0)
    return stream.read()

def main(req: func.HttpRequest) -> func.HttpResponse:
    try:
        # Defaults from environment
        workspaces_json = os.getenv("WORKSPACES_JSON", "[]")
        days = int(os.getenv("KQL_DAYS", "30"))

        # Allow override by POST body
        try:
            body = req.get_json()
        except Exception:
            body = None
        if body:
            days = int(body.get("days", days))
            if "workspaces" in body:
                workspaces_json = json.dumps(body["workspaces"])

        workspaces = json.loads(workspaces_json)
        if not isinstance(workspaces, list) or not workspaces:
            return func.HttpResponse("WORKSPACES_JSON is empty/invalid", status_code=400)

        credential = DefaultAzureCredential()
        client = LogsQueryClient(credential)
        query = kql_query(days)

        sheets_data = []
        for w in workspaces:
            sheet_name = w.get("name") or w.get("workspaceId")[:8]
            wsid = w.get("workspaceId")
            if not wsid:
                continue
            headers, rows = run_query(client, wsid, query)
            sheets_data.append((sheet_name, headers, rows))

        xlsx_bytes = to_excel(sheets_data)

        return func.HttpResponse(
            body=xlsx_bytes,
            status_code=200,
            mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            headers={"Content-Disposition": "attachment; filename=capacity-report.xlsx"}
        )

    except Exception as e:
        return func.HttpResponse(f"Error generating Excel: {str(e)}", status_code=500)
